
public class Main {

	public Main() {
		new MyFrame();
	}

	public static void main(String[] args) {
		new Main();
	}

}
