Group: Perkedel Technologies

Content:
- Leaflet
- Memo
- Letter, email version not included. you have one there.
- Business Proposal

Members:
- Joel Robert Justiawan (Founder and CEO), 2101629672
-
-
-
-

Note:
- Address of headquarter is still unknown. Perkedel thought that it would be next to Ancol, above the off coast line.
- Error occured! While Joel has learnt, they all have to learn to care. Stop being stopping people from ranting those who hinders and being luxury!!!
- Ask @JOELwindows7 on Twitter to get the truth. Recomended to not DM. Place "#WhyAlone" without quotation mark and reffer this package. expect even more confusion!
- if you lazy to do it, that is good. because it is personal trouble. Maybe some other will do it. can it be Homo Sapiens, Deus, animals?
- What does it mean by Email, Memo, Letter anyway? I lost everything!
- Sorry for inconvenience caused.
