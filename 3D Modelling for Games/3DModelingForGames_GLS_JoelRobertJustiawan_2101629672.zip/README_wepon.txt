Item Weapon

- (SWORD) Phedang
- (MACE) Mace Inducae
- (SWORD)(Optional) Side Slasher